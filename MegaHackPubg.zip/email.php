<?php
$emailku = 'valeriirussu200@gmail.com'; // GANTI EMAIL KAMU DISINI
?>